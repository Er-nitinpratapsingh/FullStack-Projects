<?php

namespace RV\Crud\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use RV\Crud\Model\ResourceModel\Collection\CollectionFactory;

/**
 * Summary of ist
 */
class Fetch extends Template
{
    public function getDataList()
    {
        // echo "working"; die;
        return $this->getData('customer_data');
    }
}
