<?php

namespace RV\Crud\Block;

use Magento\Framework\View\Element\Template;

class Edit extends Template
{
    public function getCustomerData()
    {
        return $this->getData('customer_data');

    }
    
}
