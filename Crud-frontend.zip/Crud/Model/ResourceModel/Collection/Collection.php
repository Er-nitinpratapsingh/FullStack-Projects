<?php

namespace RV\Crud\Model\ResourceModel\Collection;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use RV\Crud\Model\Entity as Model;
use RV\Crud\Model\ResourceModel\Entity as ResourceModel;

class Collection extends AbstractCollection
{
    protected $_idFieldName = 'id';
    protected $_primaryKey = 'id';
    protected $_idValue;

    protected function _construct()
    {
        $this->_init(Model::class, ResourceModel::class);
    }
}
