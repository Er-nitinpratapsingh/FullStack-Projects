<?php
namespace RV\Crud\Model;

use Magento\Framework\Model\AbstractModel;

class Entity extends AbstractModel
{
    protected $_idFieldName = 'id';
    protected $_primaryKey = 'id';
    protected $_table = 'rv_crud';

    protected $_data = [];

    protected function _construct()
    {
        $this->_init('RV\Crud\Model\ResourceModel\Entity');
    }
}
