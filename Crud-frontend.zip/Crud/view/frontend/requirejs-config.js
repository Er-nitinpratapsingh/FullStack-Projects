var config = {
    map: {
        '*': {
            'customModule': 'RV_Crud/js/alert'
        }
    }
};