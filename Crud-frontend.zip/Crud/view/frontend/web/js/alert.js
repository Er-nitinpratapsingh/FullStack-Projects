// console.log("hello");

// alert("hello");

function showAlert() {
    alert("This is a example of external js function rendering on phtml file. In which we map the js via require js file.");
}

// define([], function() {
//     'use strict';

//     return {
//         showMessage: function() {
//             alert('Custom Module JavaScript is loaded!');
//         }
//     };
// });