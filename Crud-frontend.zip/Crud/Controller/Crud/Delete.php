<?php

namespace RV\Crud\Controller\Crud;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use RV\Crud\Model\ResourceModel\Collection\CollectionFactory;
use RV\Crud\Model\EntityFactory;
use Magento\Framework\Controller\ResultFactory;



class Delete extends Action
{
    protected $resultPageFactory;
    protected $collectionFactory;
    protected $formDataFactory;

    public function __construct(
        Context $context,
        CollectionFactory $collectionFactory,
        PageFactory $resultPageFactory,
        EntityFactory $formDataFactory
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->collectionFactory = $collectionFactory;
        $this->formDataFactory = $formDataFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        // Load the customer
        $id = (int) $this->getRequest()->getParam('id');
        $formData = $this->formDataFactory->create();

        $customer = $formData->load($id);
        // print_r($customer->getData()); die;
       
        // Delete the customer
        $formData->delete($customer);
        $this->messageManager->addErrorMessage('Form record deleted!');
        return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath('crud/crud/fetch/');

        // return $this->resultPageFactory->create();
    }
}
