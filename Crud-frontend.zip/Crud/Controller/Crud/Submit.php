<?php
namespace RV\Crud\Controller\Crud;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use RV\Crud\Model\EntityFactory;

class Submit extends Action
{
    protected $formDataFactory;

    public function __construct(Context $context, EntityFactory $formDataFactory)
    {
        parent::__construct($context);
        $this->formDataFactory = $formDataFactory;
    }

    public function execute()
    {
        // Get form data
        $name = $this->getRequest()->getParam('name');
        $email = $this->getRequest()->getParam('email');
        $address = $this->getRequest()->getParam('address');

        $formData = $this->formDataFactory->create();
        $formData->setName($name);
        $formData->setEmail($email);
        $formData->setAddress($address);
        $formData->save();

        // echo "<pre>";
        // print_r($formData->getData()); die;

        // echo $message; die;

        // Do something with the data, like saving it or sending an email
        // For this example, we will just display a success message.

        $this->messageManager->addSuccessMessage('Form submitted successfully!');

        // Redirect back to the form page
        // return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath('crud/crud/fetch');
        return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setUrl('http://www.project246.magento.com/index.php/crud/crud/fetch/');
    }
}
