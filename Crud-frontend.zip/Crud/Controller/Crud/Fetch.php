<?php

namespace RV\Crud\Controller\Crud;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use RV\Crud\Model\ResourceModel\Collection\CollectionFactory;

class Fetch extends Action
{
    protected $resultPageFactory;
    protected $collectionFactory;

    public function __construct(
        Context $context,
        CollectionFactory $collectionFactory,
        PageFactory $resultPageFactory
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->collectionFactory = $collectionFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $collection = $this->collectionFactory->create();
        $collection->setOrder('created_at', 'desc');
        $resultPage = $this->resultPageFactory->create();

        $this->_view->loadLayout();
        $block = $resultPage->getLayout()->getBlock('fetch_data');
        $block->setData('customer_data', $collection);
        $this->_view->renderLayout();

        return $this->resultPageFactory->create();
    }
}
