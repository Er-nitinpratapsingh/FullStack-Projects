<?php

namespace RV\Crud\Controller\Crud;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use RV\Crud\Model\EntityFactory;
use Magento\Framework\Controller\ResultFactory;


/**
 * Summary of Edit
 */
class Edit extends Action
{
    protected $resultPageFactory;
    protected $formDataFactory;

    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        EntityFactory $formDataFactory
    ) {
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
        $this->formDataFactory = $formDataFactory;
    }

    public function execute()
    {
        $id = (int) $this->getRequest()->getParam('id');
        // $data = $this->dataModel->getDataById($id);
        $customer = $this->formDataFactory->create()->load($id);

        $resultPage = $this->resultPageFactory->create();

        try {
            $customerData = [
                'id' => $customer->getId(),
                'name' => $customer->getName(),
                'email' => $customer->getEmail(),
                'address' => $customer->getAddress()
            ];

            $this->_view->loadLayout();
            $block = $resultPage->getLayout()->getBlock('edit_form');

            // Pass the data to the template via the block
            if (!$customerData) {
                $this->messageManager->addErrorMessage('No record found!');
                return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath('crud/crud/fetch/');
                // return $this->_redirect('crud/crud/fetch');
            }

            $block->setData('customer_data', $customerData);
            $this->_view->renderLayout();


        } catch (\Exception $e) {
            $resultPage->getLayout()->getBlock('edit_form')->setData('error_message', $e->getMessage());
        }

        // Render the page
        return $this->resultPageFactory->create();
    }
}
