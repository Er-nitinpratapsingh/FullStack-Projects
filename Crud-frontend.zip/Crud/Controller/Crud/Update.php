<?php
namespace RV\Crud\Controller\Crud;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\View\Result\PageFactory;
use RV\Crud\Model\EntityFactory;

class Update extends Action
{
    protected $formDataFactory;
    protected $resultPageFactory;

    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        EntityFactory $formDataFactory
    ) {
        parent::__construct($context);
        $this->formDataFactory = $formDataFactory;
        $this->resultPageFactory = $resultPageFactory;

    }

    public function execute()
    {
        $id = (int) $this->getRequest()->getParam('id');

        // Get the data
        $name = $this->getRequest()->getParam('name');
        $email = $this->getRequest()->getParam('email');
        $address = $this->getRequest()->getParam('address');
        // Update the form
        $formData = $this->formDataFactory->create()->load($id);
        $formData->setName($name);
        $formData->setEmail($email);
        $formData->setAddress($address);
        $formData->save();

        // Display a success message.
        $this->messageManager->addSuccessMessage('Form Updated successfully!');

        // Redirect back to the list page
        // return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath('crud/crud/fetch',);
        return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setUrl('http://www.project246.magento.com/index.php/crud/crud/fetch/');
    }
}
