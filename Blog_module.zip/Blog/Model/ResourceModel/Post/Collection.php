<?php
namespace RV\Blog\Model\ResourceModel\Post;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('RV\Blog\Model\Post', 'RV\Blog\Model\ResourceModel\Post');
    }

}