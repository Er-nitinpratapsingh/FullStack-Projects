<?php
namespace RV\Blog\Model;
class Post extends \Magento\Framework\Model\AbstractModel
{
	protected function _construct()
	{
		$this->_init('RV\Blog\Model\ResourceModel\Post');
	}
}